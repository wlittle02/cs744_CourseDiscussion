package com.ocds.Dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.eclipse.persistence.jpa.jpql.parser.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ocds.Domain.Contribution;
import com.ocds.Domain.Thread;

@Controller
public class ThreadComponent {
	@Autowired
	EntityManagerFactory entitymanagerfactory;
	
	public void createThread(Thread pThread)
		
	{
		EntityManager entitymanager = entitymanagerfactory.createEntityManager(); 
		entitymanager.getTransaction().begin();
		
		entitymanager.merge(pThread);
		
		entitymanager.getTransaction().commit();
		entitymanager.close();
	}
	
	public void deleteThread(Thread pThread)
	{
		EntityManager entitymanager = entitymanagerfactory.createEntityManager();
		entitymanager.getTransaction().begin();
		
		entitymanager.remove(pThread);
		
		entitymanager.getTransaction().commit();
		entitymanager.close();
	}
	
	public List<Contribution> getAllContributions(Long pContribution)
	{
		List<Contribution> allContributions;
		EntityManager entitymanager = entitymanagerfactory.createEntityManager();
		entitymanager.getTransaction().begin();
		
		allContributions = entitymanager.createQuery("SELECT contribution FROM Contribution contribution WHERE contribution.thread = ?1")
				.setParameter(1, pContribution).getResultList();
		
		entitymanager.getTransaction().commit();
		entitymanager.close();
		return allContributions;
	}
	
	public Thread getThread(Long pThread)
	{
		EntityManager entitymanager = entitymanagerfactory.createEntityManager();
		entitymanager.getTransaction().begin();
		
		List<Thread> Threads = entitymanager.createQuery("SELECT thread FROM Thread thread WHERE thread.id = ?1")
				.setParameter(1, pThread).getResultList();
		
		entitymanager.getTransaction().commit();entitymanager.close();
		return Threads.get(0);
	}
	
	public void createContribution(Contribution pContribution)
	{
		EntityManager entitymanager = entitymanagerfactory.createEntityManager();
		entitymanager.getTransaction().begin();
		
		entitymanager.merge(pContribution);
		
		entitymanager.getTransaction().commit();
		entitymanager.close();
	}
}
